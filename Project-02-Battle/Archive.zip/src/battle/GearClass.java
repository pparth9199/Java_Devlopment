package battle;

import java.util.ArrayList;
import java.util.Collections;

/**
 * The gear class is an implementation of the gear interface the class is
 * responsible to assemble a bag of gear and give it to the players when
 * requested.
 * 
 * @author parthpatel
 *
 */
public class GearClass implements Gear {
  private final String[] headGears;
  private final String[] potions;
  private final String[] belts;
  private final String[] footWear;
  private final ArrayList<ArrayList<String>> bag;

  /**
   * The gearClass constructor assembles all the values of gears from their
   * respective enums and adds them to a bag.
   */
  public GearClass() {
    this.headGears = HeadGear.getHead();
    this.potions = Potions.getPotions();
    this.belts = Belts.getBelts();
    this.footWear = FootWear.getFootWear();
    this.bag = new ArrayList<ArrayList<String>>();
    this.bag.add(sort(this.headGears, 1));
    this.bag.add(sort(this.potions, 9));
    this.bag.add(sort(this.belts, 9));
    this.bag.add(sort(this.footWear, 1));
  }

  @Override
  public ArrayList<ArrayList<String>> getBag() {
    return this.bag;
  }

  @Override
  public ArrayList<String> sort(String[] arr, int n) {

    ArrayList<String> list = new ArrayList<String>(arr.length);
    for (int i = 0; i < arr.length; i++) {
      list.add(arr[i]);
    }
    Collections.shuffle(list);
    String[] hg = new String[n];
    for (int i = 0; i < n; i++) {
      hg[i] = list.get(i);
    }
    ArrayList<String> GearNames = new ArrayList<String>();
    for (String h : hg) {
      GearNames.add(h);
    }
    Collections.sort(GearNames, String.CASE_INSENSITIVE_ORDER);
    return GearNames;
  }

}
