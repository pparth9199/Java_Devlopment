package sanctuary;

import org.junit.Before;
import org.junit.Test;

/**
 *This class tests enclosure class.
 */
public class EnclosureTest {
  private Enclosure enc;
  private Monkey m;

  /**
   * This method sets up to initialize the constructor.
   */
  @Before
  public void setUp() {
    enc = new Enclosure(4);
    m = new Monkey(1, "Pale-headed Saki", "Pithecia", "Male", 1, 20, "eggs", 2, true, false);

  }

  /**
   * The method tests for there not to be negative values.
   */
  @Test(expected = IllegalArgumentException.class)
  public void consttest() {
    new Enclosure(-10);
  }

}
