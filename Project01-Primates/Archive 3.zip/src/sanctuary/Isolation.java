package sanctuary;

/**
 * Isolation class contains the monkeys that are in the isolation of the
 * sanctuary.
 */
public class Isolation {

}
