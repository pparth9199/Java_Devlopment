package polytest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import polynomial.Monomial;
import polynomial.Polynomial;
import polynomial.PolynomialImpl;
import polynomial.PolynomialListAdt;
import polynomial.PolynomialListAdtImpl;

public class PolynomialImplTest {
  private Polynomial p;


  @Before
  public void setUp() throws Exception {
    p = new PolynomialImpl("2x^2 +3x^1 -3 +2x^2");

  }

  @Test
  public void getCoefficientTest() {
 
    assertEquals(false,p.add(new PolynomialImpl("2x^1 +1")));

}}
